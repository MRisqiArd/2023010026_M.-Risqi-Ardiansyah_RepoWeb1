function openPopup(imageId) {
    alert('Popup untuk ' + imageId + ' akan ditampilkan di sini.');
}
